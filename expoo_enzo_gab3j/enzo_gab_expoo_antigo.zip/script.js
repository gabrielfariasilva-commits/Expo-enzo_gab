function searchContent() {
    const query = document.getElementById("search-input").value.toLowerCase();
    const sections = document.querySelectorAll("section");
  
    sections.forEach(section => {
      const text = section.innerText.toLowerCase();
      if (text.includes(query) && query.length > 0) {
        section.scrollIntoView({ behavior: "smooth", inline: "center" });
      }
    });
  }